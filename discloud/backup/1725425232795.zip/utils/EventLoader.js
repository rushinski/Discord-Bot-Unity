const fs = require('node:fs');
const { Events } = require('discord.js');
const ReadFolder = require('./ReadFolder.js');

module.exports = function (client) {
    const eventsDir = `${__dirname}/../events/`;
    if (!fs.existsSync(eventsDir)) {
        console.log('Events directory does not exist.');
        return;
    }

    const files = ReadFolder('events');
    if (files.length === 0) {
        console.log('No event files found.');
    }

    for (const { path, data } of files) {
        // Check for missing name
        if (typeof data.name !== 'string') {
            console.log(`Could not load ${path}: Missing or invalid event name.`);
            continue;
        }

        const eventName = Events[data.name] ? Events[data.name] : data.name;
        if (!Object.values(Events).includes(eventName) && !Object.keys(Events).includes(eventName)) {
            console.log(`Invalid event name "${data.name}" - Unknown to Discord.JS`);
            continue;
        }

        if (typeof data.execute !== 'function') {
            console.log(`Could not load ${path}: Missing execute function.`);
            continue;
        }

        try {
            client[data.once ? 'once' : 'on'](eventName, (...args) => data.execute(client, ...args));
        } catch (error) {
            console.error(`Error loading event "${data.name}":`, error);
        }
    }

    console.log(`Loaded ${files.length} events!`);
}
