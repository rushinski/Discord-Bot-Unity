const { ModalBuilder, TextInputBuilder, ActionRowBuilder, TextInputStyle, ChannelType, EmbedBuilder, ButtonBuilder, ButtonStyle, PermissionsBitField } = require('discord.js');
const ticket = require('../schemas/ticketSchema');
const { createTranscript } = require('discord-html-transcripts');

module.exports = {
  name: 'interactionCreate',
  async execute(interaction, client) {
    try {
      console.log(`Interaction received: ${interaction.customId}`);

      if (interaction.customId === 'ticketCreateSelect') {
        console.log('Creating ticket modal...');
        const modal = new ModalBuilder()
          .setTitle('Create your ticket')
          .setCustomId('ticketModal');

        const why = new TextInputBuilder()
          .setCustomId('whyTicket')
          .setRequired(true)
          .setPlaceholder('What is the reason for creating this ticket?')
          .setLabel('Why are you creating this ticket?')
          .setStyle(TextInputStyle.Paragraph);

        const info = new TextInputBuilder()
          .setCustomId('infoTicket')
          .setRequired(false)
          .setPlaceholder('Feel free to leave this blank')
          .setLabel('Provide us with any additional information')
          .setStyle(TextInputStyle.Paragraph);

        const one = new ActionRowBuilder().addComponents(why);
        const two = new ActionRowBuilder().addComponents(info);

        modal.addComponents(one, two);
        console.log('Showing modal to user...');
        await interaction.showModal(modal);

      } else if (interaction.customId === 'ticketModal') {
        console.log('Processing ticket modal submission...');
        const user = interaction.user;
        const data = await ticket.findOne({ Guild: interaction.guild.id });
        console.log(`Ticket data found: ${data}`);

        if (!data) {
          console.log('No ticket data found, replying with an error...');
          return await interaction.reply({ content: '⚠️ The ticket system is not set up here.', ephemeral: true });
        }

        const why = interaction.fields.getTextInputValue('whyTicket');
        const info = interaction.fields.getTextInputValue('infoTicket');
        console.log(`Ticket reason: ${why}, Additional info: ${info}`);
        
        const category = await interaction.guild.channels.cache.get(data.Category);
        console.log(`Category found: ${category?.name}`);

        const channel = await interaction.guild.channels.create({
          name: `ticket-${user.id}`,
          type: ChannelType.GuildText,
          topic: `Ticket user: ${user.username}\nReason: ${why}`,
          parent: category,
          permissionOverwrites: [
            {
              id: interaction.guild.id,
              deny: [PermissionsBitField.Flags.ViewChannel]
            },
            {
              id: interaction.user.id,
              allow: [PermissionsBitField.Flags.ViewChannel, PermissionsBitField.Flags.SendMessages, PermissionsBitField.Flags.ReadMessageHistory]
            }
          ]
        });

        console.log(`Ticket channel created: ${channel.name}`);

        const embed = new EmbedBuilder()
          .setColor('Blurple')
          .setTitle(`Ticket from ${user.username} 🎫`)
          .setDescription(`Opening Reason: ${why}\n\nExtra Information: ${info}`)
          .setTimestamp();

        const button = new ActionRowBuilder()
          .addComponents(
            new ButtonBuilder()
              .setCustomId('closeTicket')
              .setLabel('🔒 Close Ticket')
              .setStyle(ButtonStyle.Danger),
            new ButtonBuilder()
              .setCustomId('ticketTranscript')
              .setLabel('📜 Transcript')
              .setStyle(ButtonStyle.Primary)
          );

        await channel.send({ embeds: [embed], components: [button] });
        console.log('Ticket created and message sent in channel');
        await interaction.reply({ content: `✨ Your ticket has been opened in ${channel}`, ephemeral: true });

      } else if (interaction.customId === 'closeTicket') {
        console.log('Processing ticket close request...');
        const closeModal = new ModalBuilder()
          .setTitle('Ticket Closing')
          .setCustomId('closeTicketModal');

        const reason = new TextInputBuilder()
          .setCustomId('closeReasonTicket')
          .setRequired(true)
          .setPlaceholder('What is the reason for closing this ticket?')
          .setLabel('Provide a closing reason')
          .setStyle(TextInputStyle.Paragraph);

        const one = new ActionRowBuilder().addComponents(reason);

        closeModal.addComponents(one);
        console.log('Showing close modal to user...');
        await interaction.showModal(closeModal);

      } else if (interaction.customId === 'closeTicketModal') {
        console.log('Closing ticket...');
        const channel = interaction.channel;
        const name = channel.name.replace('ticket-', '');
        const member = await interaction.guild.members.cache.get(name);
        console.log(`Channel name: ${channel.name}, Member: ${member?.user.tag}`);

        const reason = interaction.fields.getTextInputValue('closeReasonTicket');
        console.log(`Close reason: ${reason}`);
        await interaction.reply({ content: '🔒 Closing this ticket...' });

        setTimeout(async () => {
          console.log('Deleting channel...');
          await channel.delete().catch(err => console.error('Error deleting channel:', err));
          console.log('Channel deleted, sending DM to user...');
          await member.send(`📢 Your ticket in ${interaction.guild.name} has been closed for: \`${reason}\``).catch(err => console.error('Error sending message to member:', err));
        }, 5000);

      } else if (interaction.customId === 'ticketTranscript') {
        console.log('Generating ticket transcript...');
        const file = await createTranscript(interaction.channel, {
          limit: -1,
          returnBuffer: false,
          filename: `${interaction.channel.name}.html`
        });

        console.log('Transcript created, sending in channel...');
        const msg = await interaction.channel.send({ content: '🌍 Your ticket transcript:', files: [file] });
        const message = `📜 **Here is your [ticket transcript](https://mahto.id/chat-exporter?url=${msg.attachments.first()?.url}) from ${interaction.guild.name}!**`;
        console.log('Transcript sent, deleting message...');
        await msg.delete().catch(err => console.error('Error deleting message:', err));
        await interaction.reply({ content: message, ephemeral: true });
      }
    } catch (error) {
      console.error('Error handling interaction:', error);
      await interaction.reply({ content: 'There was an error processing your request.', ephemeral: true });
    }
  }
}
