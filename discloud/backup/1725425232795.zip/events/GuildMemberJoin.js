const { Events } = require('discord.js');

module.exports = {
    name: Events.GuildMemberAdd,
    async execute(member) {
        try {

            // Get the welcome channel
            const channel = member.guild.channels.cache.get('1245565011942834226');
            if (!channel) {
                console.error('Channel not found.');
                return;
            }

            // Send the welcome message
            await channel.send(
                `**Welcome to VILTRUMITE EMPIRE Rok Jumping Group, <@${member.guild.me.id}>!**\n\n` +
                `We're glad to have you here! To get started:\n` +
                `- First check out <#1245565013457113138> for server rules and info.\n` +
                `- Then visit <#1245564997128683571> to verify yourself.\n\n` +
                `After completing those steps you can head over to the **Role Selection** channel so we can get to know you better!\n\n` +
                `We currently have **${member.guild.memberCount}** members jumping with us!`
            );

            console.log(`Sent a welcome message to ${member.user.tag}`);
        } catch (error) {
            console.error('Error sending welcome message:', error);
        }
    },
};
